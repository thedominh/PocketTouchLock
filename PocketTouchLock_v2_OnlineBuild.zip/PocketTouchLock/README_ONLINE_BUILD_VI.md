# Build APK online from Android phone (GitHub Actions)

1. Create/login to GitHub account in Chrome.
2. Create a new repository. Name: `PocketTouchLock`; choose Public (easiest for Actions) or Private. Do not initialize with README.
3. Upload all project files/folders from this ZIP to repository root, including `.github/workflows/build-apk.yml`. On mobile web, upload files/folders if supported; otherwise use GitHub's upload files flow. Ensure workflow file path is exactly `.github/workflows/build-apk.yml`.
4. Open repo > Actions tab > workflow `Build Pocket Touch Lock APK` > `Run workflow` > Run.
5. Wait for workflow to finish successfully (green check).
6. Open the successful run, scroll to Artifacts, download `PocketTouchLock-debug-apk` ZIP.
7. Extract it on Android. Install `app-debug.apk` (allow Chrome/Files to install unknown apps if prompted).

This workflow builds on GitHub's hosted runner. No Android build tools are needed on the phone.
