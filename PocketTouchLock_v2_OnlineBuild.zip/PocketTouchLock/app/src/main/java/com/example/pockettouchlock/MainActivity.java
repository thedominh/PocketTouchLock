package com.example.pockettouchlock;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Toast;

public class MainActivity extends Activity {
    WebView web;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "AndroidLock");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    public class Bridge {
        @android.webkit.JavascriptInterface public void setPrefs(int presses, float windowSeconds, int darkness) {
            getSharedPreferences("lockprefs", MODE_PRIVATE).edit()
                .putInt("presses", Math.max(2, Math.min(4, presses)))
                .putLong("window_ms", (long)(Math.max(0.8f, Math.min(3.0f, windowSeconds))*1000))
                .putInt("darkness", Math.max(0, Math.min(95, darkness))).apply();
        }
        @android.webkit.JavascriptInterface public void lock() {
            runOnUiThread(() -> {
                if (!Settings.canDrawOverlays(MainActivity.this)) {
                    Toast.makeText(MainActivity.this, "Please grant Display over other apps permission", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
                    return;
                }
                startService(new Intent(MainActivity.this, TouchOverlayService.class));
                Toast.makeText(MainActivity.this, "Touch lock enabled. Press Volume Up 3 times to unlock.", Toast.LENGTH_LONG).show();
            });
        }
        @android.webkit.JavascriptInterface public void unlock() {
            runOnUiThread(() -> stopService(new Intent(MainActivity.this, TouchOverlayService.class)));
        }
        @android.webkit.JavascriptInterface public boolean overlayPermission() {
            return Settings.canDrawOverlays(MainActivity.this);
        }
        @android.webkit.JavascriptInterface public void openOverlaySettings() {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())));
        }
        @android.webkit.JavascriptInterface public void openAccessibilitySettings() {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        }
    }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
