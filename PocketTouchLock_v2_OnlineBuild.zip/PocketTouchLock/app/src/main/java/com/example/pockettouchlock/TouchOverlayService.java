package com.example.pockettouchlock;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

public class TouchOverlayService extends Service {
    static TouchOverlayService active;
    WindowManager wm; FrameLayout overlay;
    @Override public void onCreate(){super.onCreate();active=this;}
    @Override public int onStartCommand(Intent intent,int flags,int startId){if(overlay==null)showOverlay();return START_STICKY;}
    private void vibrate(long ms){try{((Vibrator)getSystemService(VIBRATOR_SERVICE)).vibrate(ms);}catch(Exception ignored){}}
    private void showOverlay(){
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        overlay=new FrameLayout(this);
        int darkness=getSharedPreferences("lockprefs",MODE_PRIVATE).getInt("darkness",85);
        overlay.setBackgroundColor(Color.argb((int)(darkness*2.55),0,0,0));
        TextView label=new TextView(this);label.setText("TOUCH LOCK ACTIVE\n\nVolume + để mở khóa");label.setTextColor(Color.WHITE);label.setTextSize(18);label.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams textLp=new FrameLayout.LayoutParams(-1,-1);overlay.addView(label,textLp);
        Button emergency=new Button(this);emergency.setText("MỞ KHÓA KHẨN CẤP");
        FrameLayout.LayoutParams bLp=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);bLp.setMargins(32,0,32,40);overlay.addView(emergency,bLp);
        emergency.setOnClickListener(v->unlockNow());
        int type=WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(-1,-1,type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.TRANSLUCENT);lp.gravity=Gravity.TOP|Gravity.START;
        wm.addView(overlay,lp);vibrate(80);
    }
    public void unlockNow(){if(overlay!=null&&wm!=null){try{wm.removeView(overlay);}catch(Exception ignored){}overlay=null;}vibrate(160);stopSelf();}
    @Override public void onDestroy(){if(overlay!=null&&wm!=null){try{wm.removeView(overlay);}catch(Exception ignored){}overlay=null;}active=null;super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
