package com.example.pockettouchlock;
import android.accessibilityservice.AccessibilityService;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import android.os.Vibrator;
public class VolumeKeyAccessibilityService extends AccessibilityService {
    int count=0;long last=0;
    @Override public void onAccessibilityEvent(AccessibilityEvent e){} @Override public void onInterrupt(){}
    @Override public boolean onKeyEvent(KeyEvent e){
        if(e.getKeyCode()!=KeyEvent.KEYCODE_VOLUME_UP||e.getAction()!=KeyEvent.ACTION_DOWN||e.getRepeatCount()!=0)return false;
        long now=System.currentTimeMillis();long window=getSharedPreferences("lockprefs",MODE_PRIVATE).getLong("window_ms",1600);int needed=getSharedPreferences("lockprefs",MODE_PRIVATE).getInt("presses",3);
        if(now-last>window)count=0;last=now;count++;
        if(count>=needed){count=0;TouchOverlayService svc=TouchOverlayService.active;if(svc!=null)svc.unlockNow();}
        return false;
    }
}
