# Pocket Touch Lock v2 (Android Studio source)

Features: HTML UI; touch-blocking Android overlay; keeps screen on; configurable 2/3/4 Volume Up presses and interval; black overlay dimming; vibration on lock/unlock; emergency unlock button.

## Build APK
Open this folder in Android Studio, sync Gradle, then Build > Build APK(s). APK path: app/build/outputs/apk/debug/.

## Permissions
Grant Display over other apps. Enable the app's Accessibility service in Settings > Accessibility. This service listens for Volume Up key events; key presses are not suppressed so volume control should still work.

## Usage
Play audio, return to app, configure the unlock sequence/dimming, tap lock, then put phone in pocket. Triple (or selected count) Volume Up within selected window unlocks. Emergency unlock button is also on overlay.

Test on your own device before relying on it. Android OEM/versions may limit accessibility key filtering/overlay behavior. This is not a security lock. The black overlay dims but does not switch off the display.
